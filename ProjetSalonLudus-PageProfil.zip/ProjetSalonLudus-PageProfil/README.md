# ProjetSalonLudus
Pour faire fonctionner le Git :

  1) Avoir WampServer
  2) Clone le repo dans un dossier dans le Dossier www de WampServer.
  
Pour faire fonctionner le projet : 

  1) Avoir lancer wamp
  2) Wamp est vert
  3) Allez jusquaux repo via wamp
  4) Bien verifier que l'url est juste ( contient bien local host )
 

Pour verifier la reussite de l'installation : 

  1) pull master 
  2) lancer localhost et acceder à index.
  3) fermer la fenetre 
  4) checkout gitTest
  5) pull gitTest
  6) lancer localhost et acceder a index.



















